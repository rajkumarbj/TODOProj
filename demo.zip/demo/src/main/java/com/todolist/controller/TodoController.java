package com.todolist.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.todolist.model.Task;
import com.todolist.service.TodoService;


@RestController
@RequestMapping("/api/employees")
public class TodoController {
	
	private TodoService service;

   public TodoController(TodoService service) {
		super();
		this.service = service;
	}

   @PostMapping("/save")
	public ResponseEntity<Task> saveTodo(@RequestBody Task task){
		return new ResponseEntity<Task>(service.Save(task),HttpStatus.CREATED);
		
	}

	@GetMapping("/get")
	public List<Task> GetTodos(){
		return service.getAllTodo();
		
	}

	
	@PutMapping("/update/{id}")
	public ResponseEntity<Task> UpdateEmployeesById(@RequestBody Task task,@PathVariable("id") long id){
		return new ResponseEntity<Task>(service.update(task, id), HttpStatus.OK);
		
	}
	

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> Delete(@PathVariable("id") long id){
		service.delete(id);
		return new ResponseEntity<String>("todo deleted succesafully", HttpStatus.OK);
		
	}
}
