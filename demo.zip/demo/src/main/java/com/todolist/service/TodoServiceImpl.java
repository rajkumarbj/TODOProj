package com.todolist.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import com.todolist.model.Task;
import com.todolist.repository.TodoRepository;

@Service
public class TodoServiceImpl implements TodoService {

	
	private TodoRepository repository;
	
	public TodoServiceImpl(TodoRepository repository) {
		super();
		this.repository = repository;
	}

	@Override
	public Task Save(Task task) {
		// TODO Auto-generated method stub
		return repository.save(task);
	}

	@Override
	public List<Task> getAllTodo() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Task update(Task task, long id)  {
		// TODO Auto-generated method stub
		Task ptask= repository.findById((int)id).get();
		ptask.setName(task.getName());
		ptask.setStatus(task.isStatus());
		repository.save(ptask);
		return ptask;
		
	}

	@Override
	public void delete(long id) {
		repository.deleteById((int)id);
		
	}

}
