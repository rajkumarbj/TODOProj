package com.todolist.service;

import java.util.List;

import org.springframework.stereotype.Service;


import com.todolist.model.Task;


public interface TodoService {
	
	Task Save(Task task);
	List<Task> getAllTodo();
	Task update(Task task, long id);
	void delete(long id);
	
	
	

}
