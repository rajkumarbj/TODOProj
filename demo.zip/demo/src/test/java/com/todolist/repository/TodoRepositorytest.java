package com.todolist.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.todolist.model.Task;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class TodoRepositorytest {
	

    @Autowired
    private TodoRepository repo;
    
    @Test
    @Rollback(false)
    public void testCreateTodo() {
   Task saveTask = repo.save(new Task(1,"adding the data", false));
    
   assertThat(saveTask.getId()).isGreaterThan(0);
    }


    
    @Test
    public void testListProducts() {
        List<Task> products = (List<Task>) repo.findAll();
        assertThat(products).size().isGreaterThan(0);
    }
    
    
    @Test
    @Rollback(false)
    public void testUpdateProduct() {
        Task task = repo.findById(1).get();
        task.setName("updated"); 
        repo.save(task); 
        Task updatedtask= repo.findById(1).get();
         
        assertThat(updatedtask.getName()).isEqualTo("updated");
    }
    
    
    @Test
    @Rollback(false)
    public void testDeleteProduct() {
    	 Task task = repo.findById(1).get(); 
        repo.deleteById((int)task.getId());
        Task deletedtask = repo.findById(1).get(); 
        assertThat(deletedtask).isNull();       
         
    }
}


